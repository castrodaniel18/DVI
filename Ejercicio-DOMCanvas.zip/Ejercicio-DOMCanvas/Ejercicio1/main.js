console.log("Hola, mundo!");
window.onload = function () {
    document.body.innerHTML = '<h1>Hola, mundo!</h1>';
};